package com.epsandes.controller;

import com.epsandes.service.CitaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.modelo.Cita;

import java.util.List;

@RestController
@RequestMapping("/citas")
public class CitaController {
    @Autowired
    private CitaService citaService;

    @GetMapping
    public List<Cita> obtenerTodasLasCitas() {
        return citaService.obtenerTodasLasCitas();
    }

    @PostMapping
    public Cita agendarCita(@RequestBody Cita cita) {
        return citaService.agendarCita(cita);
    }

    @GetMapping("/{id}")
    public Cita obtenerCitaPorId(@PathVariable Long id) {
        return citaService.obtenerCitaPorId(id);
    }

    @PutMapping("/{id}/cancelar")
    public void cancelarCita(@PathVariable Long id) {
        citaService.cancelarCita(id);
    }
}