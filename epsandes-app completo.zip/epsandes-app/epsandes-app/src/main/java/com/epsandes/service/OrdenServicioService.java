package com.epsandes.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epsandes.repository.OrdenServicioRepository;
import com.modelo.OrdenServicio;

@Service
public class OrdenServicioService {
    @Autowired
    private OrdenServicioRepository ordenServicioRepository;

    public void registrarOrdenServicio(OrdenServicio ordenServicio) {
        ordenServicio.setEstado("Vigente");
        ordenServicioRepository.save(ordenServicio);
    }
}
