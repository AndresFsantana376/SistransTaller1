package com.epsandes.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.modelo.EPS;

public interface EPSRepository extends JpaRepository<EPS, String> {
}