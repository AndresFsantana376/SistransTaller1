package com.epsandes.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epsandes.repository.CitaRepository;
import com.modelo.Cita;

import java.util.List;

@Service
public class CitaService {
    @Autowired
    private CitaRepository citaRepository;

    public List<Cita> obtenerTodasLasCitas() {
        return citaRepository.findAll();
    }

    public Cita agendarCita(Cita cita) {
        return citaRepository.save(cita);
    }

    public Cita obtenerCitaPorId(Long id) {
        return citaRepository.findById(id).orElse(null);
    }

    public void cancelarCita(Long id) {
        Cita cita = citaRepository.findById(id).orElse(null);
        if (cita != null) {
            cita.setEstado("cancelada");
            citaRepository.save(cita);
        }
    }
}