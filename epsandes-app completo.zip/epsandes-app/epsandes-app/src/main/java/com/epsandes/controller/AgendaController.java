package com.epsandes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.epsandes.service.AgendaService;

@RestController
@RequestMapping("/agenda")
public class AgendaController {
    @Autowired
    private AgendaService agendaService;

    @PostMapping("/agendar")
    public ResponseEntity<String> agendarServicio(@RequestParam Long ordenId, @RequestParam Long agendaId) {
        agendaService.agendarServicio(ordenId, agendaId);
        return ResponseEntity.ok("Servicio agendado exitosamente");
    }
}