package com.epsandes.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.modelo.Agenda;

public interface AgendaRepository extends JpaRepository<Agenda, Long> {
}
