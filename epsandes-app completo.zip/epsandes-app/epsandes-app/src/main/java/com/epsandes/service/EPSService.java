package com.epsandes.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epsandes.repository.EPSRepository;
import com.modelo.EPS;

import java.util.List;

@Service
public class EPSService {
    @Autowired
    private EPSRepository epsRepository;

    public List<EPS> obtenerTodasLasEPS() {
        return epsRepository.findAll();
    }

    public EPS registrarEPS(EPS eps) {
        return epsRepository.save(eps);
    }

    public EPS obtenerEPSPorNit(String nit) {
        return epsRepository.findById(nit).orElse(null);
    }
}