package com.epsandes.epsandes_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EpsandesAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EpsandesAppApplication.class, args);
	}

}
