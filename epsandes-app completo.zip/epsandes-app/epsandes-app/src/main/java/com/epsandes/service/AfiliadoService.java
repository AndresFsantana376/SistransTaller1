package com.epsandes.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epsandes.repository.AfiliadoRepository;
import com.modelo.Afiliado;

@Service
public class AfiliadoService {
    @Autowired
    private AfiliadoRepository afiliadoRepository;

    public void registrarAfiliado(Afiliado afiliado) {
        afiliadoRepository.save(afiliado);
    }
}