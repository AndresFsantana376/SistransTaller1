package com.epsandes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.epsandes.service.OrdenServicioService;
import com.modelo.OrdenServicio;

@RestController
@RequestMapping("/ordenes")
public class OrdenServicioController {
    @Autowired
    private OrdenServicioService ordenServicioService;

    @PostMapping
    public ResponseEntity<String> registrarOrdenServicio(@RequestBody OrdenServicio ordenServicio) {
        ordenServicioService.registrarOrdenServicio(ordenServicio);
        return ResponseEntity.ok("Orden de servicio registrada exitosamente");
    }
}
