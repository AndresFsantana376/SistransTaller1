package com.epsandes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.epsandes.service.EPSService;
import com.modelo.EPS;


import java.util.List;

@RestController
@RequestMapping("/eps")
public class EPSController {
    @Autowired
    private EPSService epsService;

    @GetMapping
    public List<EPS> obtenerTodasLasEPS() {
        return epsService.obtenerTodasLasEPS();
    }

    @PostMapping
    public EPS registrarEPS(@RequestBody EPS eps) {
        return epsService.registrarEPS(eps);
    }

    @GetMapping("/{nit}")
    public EPS obtenerEPSPorNit(@PathVariable String nit) {
        return epsService.obtenerEPSPorNit(nit);
    }
}