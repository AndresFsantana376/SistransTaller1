package com.epsandes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.epsandes.service.AfiliadoService;
import com.modelo.Afiliado;

@RestController
@RequestMapping("/afiliados")
public class AfiliadoController {
    @Autowired
    private AfiliadoService afiliadoService;

    @PostMapping
    public ResponseEntity<String> registrarAfiliado(@RequestBody Afiliado afiliado) {
        afiliadoService.registrarAfiliado(afiliado);
        return ResponseEntity.ok("Afiliado registrado exitosamente");
    }
}
