package com.epsandes.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.modelo.IPS;

public interface IPSRepository extends JpaRepository<IPS, String> {
}
