package com.epsandes.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.modelo.Medico;

public interface MedicoRepository extends JpaRepository<Medico, Long> {
}
