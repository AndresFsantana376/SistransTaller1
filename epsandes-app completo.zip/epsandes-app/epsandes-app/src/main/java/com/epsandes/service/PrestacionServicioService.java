package com.epsandes.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epsandes.repository.PrestacionServicioRepository;
import com.modelo.PrestacionServicio;

@Service
public class PrestacionServicioService {
    @Autowired
    private PrestacionServicioRepository prestacionServicioRepository;

    public void registrarPrestacionServicio(PrestacionServicio prestacionServicio) {
        prestacionServicioRepository.save(prestacionServicio);
    }
}