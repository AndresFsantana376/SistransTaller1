package com.epsandes.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.epsandes.repository.IPSRepository;
import com.modelo.IPS;

@Service
public class IPSService {
    @Autowired
    private IPSRepository ipsRepository;

    public void registrarIPS(IPS ips) {
        ipsRepository.save(ips);
    }
}

