package com.epsandes.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.epsandes.repository.IPSRepository;
import com.epsandes.repository.ServicioSaludRepository;
import com.modelo.IPS;
import com.modelo.ServicioSalud;

@Service
public class AsignacionService {
    @Autowired
    private IPSRepository ipsRepository;

    @Autowired
    private ServicioSaludRepository servicioSaludRepository;

    public void asignarServicioIPS(String ipsNit, String servicioCodigo) {
        // Buscar la IPS por su NIT
        IPS ips = ipsRepository.findById(ipsNit)
                .orElseThrow(() -> new RuntimeException("IPS no encontrada"));

        // Buscar el servicio por su código
        ServicioSalud servicio = servicioSaludRepository.findById(servicioCodigo)
                .orElseThrow(() -> new RuntimeException("Servicio no encontrado"));

        // Asignar el servicio a la IPS
        ips.getServicios().add(servicio);

        // Guardar la IPS actualizada
        ipsRepository.save(ips);
    }
}
