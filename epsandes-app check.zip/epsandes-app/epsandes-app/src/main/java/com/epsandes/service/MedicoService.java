package com.epsandes.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.epsandes.repository.MedicoRepository;
import com.modelo.Medico;

@Service
public class MedicoService {
    @Autowired
    private MedicoRepository medicoRepository;

    public void registrarMedico(Medico medico) {
        medicoRepository.save(medico);  // Esto debería funcionar ahora
    }
}
