package com.epsandes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.epsandes.service.IPSService;
import com.modelo.IPS;

@RestController
@RequestMapping("/ips")
public class IPSController {
    @Autowired
    private IPSService ipsService;

    @PostMapping
    public ResponseEntity<String> registrarIPS(@RequestBody IPS ips) {
        ipsService.registrarIPS(ips);
        return ResponseEntity.ok("IPS registrada exitosamente");
    }
}