package com.epsandes.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epsandes.repository.ServicioSaludRepository;
import com.modelo.ServicioSalud;

@Service
public class ServicioSaludService {
    @Autowired
    private ServicioSaludRepository servicioSaludRepository;

    public void registrarServicioSalud(ServicioSalud servicioSalud) {
        servicioSaludRepository.save(servicioSalud);
    }
}