package com.epsandes.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.modelo.PrestacionServicio;

public interface PrestacionServicioRepository extends JpaRepository<PrestacionServicio, Long> {
}