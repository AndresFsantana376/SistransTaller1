package com.epsandes.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epsandes.repository.AgendaRepository;
import com.epsandes.repository.OrdenServicioRepository;
import com.modelo.Agenda;
import com.modelo.OrdenServicio;

@Service
public class AgendaService {
    @Autowired
    private AgendaRepository agendaRepository;
    @Autowired
    private OrdenServicioRepository ordenServicioRepository;

    public void agendarServicio(Long ordenId, Long agendaId) {
        OrdenServicio orden = ordenServicioRepository.findById(ordenId).orElseThrow(() -> new RuntimeException("Orden no encontrada"));
        Agenda agenda = agendaRepository.findById(agendaId).orElseThrow(() -> new RuntimeException("Agenda no encontrada"));

        if (!agenda.isDisponible()) {
            throw new RuntimeException("El horario no está disponible");
        }

        agenda.setDisponible(false);
        agendaRepository.save(agenda);

        orden.setEstado("Completada");
        ordenServicioRepository.save(orden);
    }
}