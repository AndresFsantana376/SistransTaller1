package com.epsandes.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.modelo.Afiliado;

public interface AfiliadoRepository extends JpaRepository<Afiliado, Long> {
}