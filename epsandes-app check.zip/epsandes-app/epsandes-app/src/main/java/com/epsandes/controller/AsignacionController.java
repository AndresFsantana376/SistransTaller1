package com.epsandes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.epsandes.service.AsignacionService;

@RestController
@RequestMapping("/asignaciones")
public class AsignacionController {
    @Autowired
    private AsignacionService asignacionService;

    @PostMapping
    public ResponseEntity<String> asignarServicioIPS(
            @RequestParam String ipsNit,
            @RequestParam String servicioCodigo) {
        asignacionService.asignarServicioIPS(ipsNit, servicioCodigo);
        return ResponseEntity.ok("Servicio asignado a IPS exitosamente");
    }
}
