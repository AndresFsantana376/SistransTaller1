package com.epsandes.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.modelo.OrdenServicio;


public interface OrdenServicioRepository extends JpaRepository<OrdenServicio, Long> {
}
