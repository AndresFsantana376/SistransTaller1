package com.modelo;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "AGENDA")
public class Agenda {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "ips_nit")
    private IPS ips;

    @ManyToOne
    @JoinColumn(name = "servicio_codigo")
    private ServicioSalud servicio;

    @ManyToOne
    @JoinColumn(name = "medico_id")
    private Medico medico;

    private Date fecha;
    private String hora;
    private boolean disponible;
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public IPS getIps() {
        return ips;
    }
    public void setIps(IPS ips) {
        this.ips = ips;
    }
    public ServicioSalud getServicio() {
        return servicio;
    }
    public void setServicio(ServicioSalud servicio) {
        this.servicio = servicio;
    }
    public Medico getMedico() {
        return medico;
    }
    public void setMedico(Medico medico) {
        this.medico = medico;
    }
    public Date getFecha() {
        return fecha;
    }
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    public String getHora() {
        return hora;
    }
    public void setHora(String hora) {
        this.hora = hora;
    }
    public boolean isDisponible() {
        return disponible;
    }
    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    
}